var regions = [
	'us-east-1',		// Northern Virginia
	'us-east-2',		// Ohio
	'us-west-1',		// Northern California
	'us-west-2',		// Oregon
	'ap-northeast-1',	// Asia Pacific (Tokyo)
	'ap-northeast-2',	// Asia Pacific (Seoul)
	'ap-southeast-1',	// Asia Pacific (Singapore)
	'ap-southeast-2',	// Asia Pacific (Sydney)
	'eu-central-1',		// EU (Frankfurt)
	'eu-west-1',		// EU (Ireland)
	'eu-west-2',		// London
	'eu-west-3',		// Paris
	'sa-east-1',		// South America (São Paulo)
	'ap-south-1',		// Mumbai
	'ca-central-1'		// Canada (Montreal)
];

module.exports = {
	all: regions,
	cloudfront: ['us-east-1'], // CloudFront uses the default global region
	autoscaling: regions,
	iam: ['us-east-1'],
	route53: ['us-east-1'],
	route53domains: ['us-east-1'],
	s3: ['us-east-1'],
	cloudtrail: regions,
	cloudwatchlogs: regions,
	configservice: regions,
	ec2: regions,
	elb: regions,
	elbv2: regions,
	firehose: regions,
	kms: regions,
	vpc: regions,
	flowlogs: regions,
	rds: regions,
	redshift: regions,
	apigateway: [
		'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
		'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1',
		'ap-southeast-1', 'ap-northeast-1'],
	cloudwatch: regions,
	dynamodb: regions,
	ecr: [
		'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2', 'ca-central-1',
		'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1',
		'ap-northeast-1', 'ap-southeast-1', 'ap-southeast-2'],
	ecs: [
		'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2', 'ca-central-1',
		'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1',
		'ap-southeast-1', 'ap-northeast-1', 'ap-southeast-2'],
	ses: [
		'us-east-1', 'us-west-2',
		'eu-west-1'],
	sns: regions,
	sqs: regions,
	sts: ['us-east-1'],
	lambda: ['us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
			 'eu-west-1', 'eu-central-1', 'eu-west-2', 'eu-west-3', 'ap-southeast-1',
			 'ap-southeast-2', 'ap-northeast-1', 'ap-northeast-2',
			 'ap-south-1'],
	directconnect: regions,
	directoryservice: ['us-east-1', 'us-east-2', 'us-west-2', 'us-west-1', 'ca-central-1',
					   'sa-east-1', 'eu-west-1', 'eu-central-1', 'eu-west-2',
					   'ap-southeast-1', 'ap-northeast-1', 'ap-southeast-2', 'ap-northeast-2',
					   'ap-south-1']
};